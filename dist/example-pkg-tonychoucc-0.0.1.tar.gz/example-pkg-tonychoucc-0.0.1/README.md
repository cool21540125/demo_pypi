# Test PyPI

- https://packaging.python.org/tutorials/packaging-projects/#setup-py
- 2019/12/23

```bash
pip install --user --upgrade setuptools wheel

python setup.py sdist bdist_wheel
```